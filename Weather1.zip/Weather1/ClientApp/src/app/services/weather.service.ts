import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class WeatherService {

    constructor(private http: HttpClient,) { }
    
    /**
     * HTTP POST request to external url
     * @param url
     * @param options
     */
    public get<T = any>(url: string = '', options?: any) {
        return this.http.get(url, options);
    }
}
