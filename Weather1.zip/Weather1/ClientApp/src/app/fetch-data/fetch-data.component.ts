import { Component, Inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { WeatherService } from '../services/weather.service';

@Component({
    selector: 'app-fetch-data',
    templateUrl: './fetch-data.component.html',
    styleUrls: ['./fetch-data.component.css']
})

export class FetchDataComponent {
    public forecasts: any;
    public countries: any;
    public tempCity: any;
    public baseURL: string;
    constructor(
        http: HttpClient,
        @Inject('BASE_URL') baseUrl: string,
        private weatherService: WeatherService,
    ) {
        this.baseURL = baseUrl;
        this.weatherService.get(baseUrl + 'Api/Weather/GetCountries')
            .subscribe(result => {
                this.countries = result;
            }, error => console.error(error));
        
    }

    public updateCity(e) {
        this.tempCity = this.countries.find(object => object.Key == e.target.value);
    }

    public updateWeather(e) {
        this.weatherService.get(this.baseURL + 'Api/Weather/WeatherForecast/'+e.target.value)
            .subscribe(result => {
                this.forecasts = result;
            }, error => console.error(error));
    }
}