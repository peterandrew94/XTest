﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using Weather1.Models;

namespace Weather1.Controllers
{
    [ApiController]
    [Route("Api/Weather")]
    public class WeatherForecastController : ControllerBase
    {
        [HttpGet, Route("GetCountries")]
        public dynamic GetCountries()
        {
            var countriesObject = GetJSONData("https://countriesnow.space/api/v0.1/countries");

            Dictionary<string, string[]> countries = new Dictionary<string, string[]>();

            foreach (var temp in countriesObject.data)
            {
                string country = Convert.ToString(temp.country);
                string[] cities = temp.cities.ToObject<string[]>();
                
                if (!countries.ContainsKey(country) && cities.Length > 0)
                    countries.Add(country, cities);
            }

            return countries.ToList();
        }

        [HttpGet, Route("WeatherForecast/{pCity}")]
        public WeatherForecast Get(string pCity)
        {
            var weatherObject = GetJSONData("https://api.openweathermap.org/data/2.5/weather?q="+ pCity + "&appid=472fc17833b8b61a5de73148272710a7");
            
            return new WeatherForecast
            {
                Location = "Latitude : " + weatherObject.coord.lat +", Longitude : " + weatherObject.coord.lon,
                Time = DateTime.Now.ToUniversalTime().AddHours(Convert.ToDouble(weatherObject.timezone/3600)).ToString("dd/MM/yyyy HH:mm"),
                Wind = "Speed : "+ weatherObject.wind.speed +", Degree: "+ weatherObject.wind.deg,
                Visibility = weatherObject.visibility,
                SkyConditions = weatherObject.weather[0].main,
                TemperatureKelvin = weatherObject.main.temp,
                DewPoint = "-",
                Humidity = weatherObject.main.humidity,
                Pressure = weatherObject.main.pressure
            };
        }

        private dynamic GetJSONData(string url) {
            HttpWebRequest WebReq = (HttpWebRequest)WebRequest.Create(string.Format(url));

            WebReq.Method = "GET";

            HttpWebResponse WebResp = (HttpWebResponse)WebReq.GetResponse();

            string jsonString;
            using (Stream stream = WebResp.GetResponseStream())
            {
                StreamReader reader = new StreamReader(stream, System.Text.Encoding.UTF8);
                jsonString = reader.ReadToEnd();
            }
            
            return JsonConvert.DeserializeObject<dynamic>(jsonString);
        }
    }
}
